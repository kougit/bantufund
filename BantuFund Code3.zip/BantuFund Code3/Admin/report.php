
<?php 
session_start();
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Report</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- jQuery UI -->
    <link href="https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css" rel="stylesheet" media="screen">

    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="css/styles.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  <?php require("conbfclean.php"); ?>

  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="index.php">BantuFund</a></h1>
	              </div>
	           </div>
	           <div class="col-md-5">
	              <div class="row">
	                <div class="col-lg-12">
	                  
	                </div>
	              </div>
	           </div>
	           <div class="col-md-2">
	              <div class="navbar navbar-inverse" role="banner">
                    <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
                      <ul class="nav navbar-nav">
                        <li class="dropdown">
                          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Admin <b class="caret"></b></a>
                          <ul class="dropdown-menu animated fadeInUp">
                            
                            <li><a href="http://localhost/BantuFundClean/logout.php">Logout</a></li>
                          </ul>
                        </li>
                      </ul>
                    </nav>
                </div>
	           </div>
	        </div>
	     </div>
	</div>

    <div class="page-content">
    	<div class="row">
		  <div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <!-- Main menu -->
                    <li ><a href="http://localhost/BantuFundClean/Admin/index.php"><i class="glyphicon glyphicon-home"></i> Home</a></li>
                    
                    
                    <li class="current"><a href="report.php"><i class="glyphicon glyphicon-list"></i> Report</a></li>
                    <li><a href="stats.php"><i class="glyphicon glyphicon-stats"></i> Charts</a></li>
					<li><a href="adminweightfront.php"><i class="glyphicon glyphicon-stats"></i> Qualitative Analysis</a></li>


                      <li class="submenu">
                         <a href="#">
                            <i class="glyphicon glyphicon-list"></i> Pages
                            <span class="caret pull-right"></span>
                         </a>
                         <!-- Sub menu -->
                         <ul>
                            <li><a href="http://localhost/BantuFundClean/index.php">Login</a></li>
                            <li><a href="http://localhost/BantuFundClean/index.php">Signup</a></li>
                        </ul>
                    </li>
                </ul>
             </div>
		  </div>
		  <div class="col-md-10">

		   <div class="row"> 
  			
		   		<?php 

                    $seshpjtid = $_SESSION['pjtid'];
                  //retrieving posts from database and displaying them
                                      //retrieving from database
                   // $sqlselect ='SELECT image,drivename,driveID FROM drive';
                    //$sqlselect ='SELECT * FROM donation';
                     
                     $sqlselect ="SELECT * FROM `donation` LEFT JOIN `caller` ON `caller`.`Caller_ID`=`donation`.`Caller_ID` WHERE `Drive_ID`='$seshpjtid'" ;
                      //validating 
                      $retval= mysqli_query($link, $sqlselect);
                      if ($retval ){
                            //echo "<p>selection2 success</p>";
                      }
                      else {
                            echo "Error: " . $sqlselect . "<br>" . mysqli_error($link);
                    } 
                                
                 ?>

  			<div class="content-box-large">
  			<div class="panel-heading">
					<div class="panel-title" id="drivename"> <?php echo $_SESSION['pjtname']; ?> </div>          
				</div>
  				<div class="panel-body">
            <span>
              Goal:&nbsp<b><?php echo $_SESSION['tgtamt'];?></b>
              &nbsp&nbsp&nbsp&nbsp  Remaining Amount:&nbsp<b><?php echo $_SESSION['remainingamt'];?></b>
              &nbsp&nbsp&nbsp&nbsp  Days remaining:&nbsp<b><?php echo $_SESSION['daysrem'];?>days</b>
            </span>
            
  					<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
						<thead>
							<tr>
								<th>Funder ID</th>
								<th>Funder Name</th>
								<th>Amount Donated</th>
								<th>Date</th>
                <th>Amount_Collected</th> 
								<th>Percentage</th>								
							</tr>
						</thead>

						<tbody>

						<?php //loop through associative array returned from database
                       		while ($row = mysqli_fetch_assoc($retval)) {
                        ?>

							<tr class="odd gradeX">								
								<td><?php echo $row['Caller_ID'];?></td>
                <td class="center"><?php echo $row['Caller_Username'];?>  </td>
								<td><?php echo $row['Donation_Amount'];?></td>
								<td class="center"><?php echo $row['Time_Stamp'];?>  </td>
                <td>shs <?php echo $row['Donation_So_Far'];?></td>
                <td><?php echo $row['Percent'];?>%</td>

							</tr>						
							
						</tbody>
         

                   <?php  
                      }
                       mysqli_close($link); 
                   ?> 

					</table>
  				</div>
  			</div>



		  </div>
		</div>
    </div>

    <footer>
         <div class="container">
         
            <div class="copy text-center">
               CyberSolutions <a href='#'>Website</a>
            </div>
            
         </div>
      </footer>

     <link href="vendors/datatables/dataTables.bootstrap.css" rel="stylesheet" media="screen">

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>

    <script src="vendors/datatables/js/jquery.dataTables.min.js"></script>

    <script src="vendors/datatables/dataTables.bootstrap.js"></script>

    <script src="js/custom.js"></script>
    <script src="js/tables.js"></script>

    <script language="javascript" type="text/javascript">
/* <![CDATA[ */
      document.write('<a id="pdf-generate" href="http://localhost/BantuFundClean/mpdf60/starter/starter.php?url=' + encodeURIComponent(location.href) +'" class="button">');
      document.write('<img src="http://your-website/images/pdf.jpg" alt="Generate PDF">');
      document.write('</a>');
/* ]]> */
</script>

  </body>
</html>
<?php
session_start();
if( !isset( $_SESSION['username'] ) )//this means the counter has been set so the and this value leads to true
  {
    $msg = "login";
      }
  else
  {
    $msg = $_SESSION['username'];
  }

?>
<!DOCTYPE html>
	<html lang="en">

	<head>
		<meta charset="utf-8">
    <!-- Set the viewport so this responsive site displays correctly on mobile devices -->
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <title>Admin Detailed Projects Page</title>
	    <!-- Include bootstrap CSS   <link href="includes/styles.css" rel="stylesheet" />-->
	    <link href="includes/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" />
     <link href="admincustomnavbar.css" rel="stylesheet" />
	  
	</head>

	<body>
    <?php require("connection.php"); ?>
		<div class="container">

    <header>

      <nav class="navbar navbar-fixed-top navbar-default" >

        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">BantuFund</a>
          </div>


          <div id="navbar" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
              <li><a href="adminhomepage.php">AllDrives</a></li> 
              <li><a href="approved.php">Approved</a></li>           
              <li><a href="pending.php">Pending</a></li>
              <li><a href="declined.php">Declined</a></li>
            </ul>

           <span class="dropdown" style="float: right;">
              <a class="navbar-brand dropdown-toggle" data-toggle="dropdown" href="#">
              .<span class="caret"></span>
              </a>
              <ul class="dropdown-menu" role="menu" aria-labelledby="dropDownMenu1" >
                 <li role="presentation"><a role="menuitem" tabindex="-1" href="logout.php">Log out</a></li>
                <li role="presentation"><a role="menuitem" tabindex="-1" href="profilenew.php">Account</a></li>
              </ul>    
            </span> 

            <span style="float: right;">             
        <a class="navbar-brand dropdown-toggle" href="<?php if($msg == "login"){echo"loginpage.php";}else{echo "callerhomepage.php";}?>">admin<?php echo($msg);?>
        </a>
            </span>   


          </div><!-- /.nav-collapse -->

        </div><!-- /.container -->

      </nav><!-- /.navbar -->
      
    </header>
</br>
</br>
</br>
    <!-- site img and abt, donate   -->
    <div class="middle">
        
    	<div class="container">
      <?php 
        $imgnameform = $_POST['formimgname'];
        $pjtnameform = $_POST['formpjtname'];
        $pjtidform   = $_POST['formpjtid'];

      ?>
       
        <h3> <?php echo "$pjtnameform"; ?>  </h3> 
    		<div class="col-md-6"> 
              		
    			<img src="<?php echo "$imgnameform"?>" class="img-thumbnail"> 

          <form name="statusform" class="form-inline" action="processadmin.php" method="POST">
            <div class="btn-group" data-toggle="buttons">
                  <label class="btn btn-lg btn-danger">
                    <input type="radio" name="options" id="option1" autocomplete="off" value="declined" checked=""/>
                    <span class="glyphicon glyphicon-remove-circle" >DECLINE</span>
                    
                  </label>

                   <label class="btn btn-lg btn-warning">
                    <input type="radio" name="options" id="option2" autocomplete="off" value="pending" checked="" />
                    <span class="glyphicon glyphicon-warning-sign">PENDING</span>
                    
                  </label>

                   <label class="btn btn-lg btn-success">
                    <input type="radio" name="options" id="option3" autocomplete="off" value="approved" checked="" />
                    <span class="glyphicon glyphicon-ok-circle">APPROVE</span>
                    
                  </label>
                 
               </div>
            <input type="hidden" name="fmprojid"   value=" <?php echo $pjtidform; ?> ">
            <input type="submit" >
            <p><span id="errorMessage"></span></p>
          </form>                             

    		</div>

    		<div class="col-md-5">
    			<div class="content">
				<!-- About-->
				  <iframe class="About" src="aboutpage.php" width="555" height="350" > 
				    &lt;div&gt;This shall contain the information about the roject
    				T44TYGYGO
    				&lt;/div&gt;
				 </iframe>    				
				</div>
    			
    		</div>

    	</div>

    </div>

<!-- img on clicking gallery-->
     <footer>
        <p>&copy; CyberSolutions, Inc.</p>
      </footer>




	 <!-- Include jQuery and bootstrap JS plugins  <script  src="bantujs.js"></script>          -->
      
     <script src="includes/jquery/jquery.js"></script>
      <script src="includes/bootstrap/dist/js/bootstrap.min.js"></script>
 <script type="text/javascript" src="detailedadmin.js" ></script>

     
      

	</body>
</html>
<?php
//include'contry.php'; 
		//php file to retrieve from database

			$hostname="127.0.0.1";
			$dbuser  ="root";
			$dbpassword="";
			$dbname = "bantufundclean";

			$link = mysqli_connect($hostname,$dbuser,$dbpassword,$dbname); 
			

			if (!$link){ 
				die('Could not connect to MySQL35: ' . mysqli_error()); 
			} 
			
			echo 'Connection OK'; 

			//mysqli_close($link); for closing dont database connection dont forget it
		
?>
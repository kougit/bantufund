<?php
//session_start();
require("conbfclean.php"); 

    $sqlselect =" SELECT * FROM  account";
                 //validating 
    $retval= mysqli_query($link, $sqlselect);
    $chart_data  ='';

      if (!$retval ){
       echo "Error: " . $sqlselect . "<br>" . mysqli_error($link);
      }
      
      while ($row = mysqli_fetch_array($retval,MYSQLI_BOTH)) {

          $chart_data .="{year:'".$row["year"]."', profit:".$row["profit"].", purchase:".$row["purchase"].",sale:".$row["sale"]."},";  

          //"{year:'".$row["year"]."',profit:".$row["profit"].",purchase:".$row["purchase"].",sale:".$row["sale"].",}";
      } 
      
      $chart_data = substr($chart_data,0,-2);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Charts</title>
	   <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>


</head>


<body>

	<div class="container" style="width: 900px;">
		<div id="chart">
			
		</div>
	</div>

</body>
</html>
 <script>
       Morris.Line({
  
  element: 'chart',
  data: [<?php echo $chart_data;?>],
  xkey: 'year',
  ykeys: ['profit','purchase','sale'],
  labels: ['profit','purchase','sale'],
  hideHover:'auto'
});
    </script>

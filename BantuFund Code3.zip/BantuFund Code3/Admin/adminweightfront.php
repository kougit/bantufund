
<?php 
session_start();
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Report</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- jQuery UI -->
    <link href="https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css" rel="stylesheet" media="screen">

    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="css/styles.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  <?php require("conbfclean.php"); ?>

  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="index.php">BantuFund</a></h1>
	              </div>
	           </div>
	           <div class="col-md-5">
	              <div class="row">
	                <div class="col-lg-12">
	                  
	                </div>
	              </div>
	           </div>
	           <div class="col-md-2">
	              <div class="navbar navbar-inverse" role="banner">
                    <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
                      <ul class="nav navbar-nav">
                        <li class="dropdown">
                          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Admin <b class="caret"></b></a>
                          <ul class="dropdown-menu animated fadeInUp">
                            
                            <li><a href="http://localhost/BantuFundClean/logout.php">Logout</a></li>
                          </ul>
                        </li>
                      </ul>
                    </nav>
                </div>
	           </div>
	        </div>
	     </div>
	</div>

    <div class="page-content">
    	<div class="row">
		  <div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <!-- Main menu -->
                    <li ><a href="http://localhost/BantuFundClean/Admin/index.php"><i class="glyphicon glyphicon-home"></i> Home</a></li>
                    
                    
                    <li ><a href="report.php"><i class="glyphicon glyphicon-list"></i> Report</a></li>
                    <li><a href="stats.php"><i class="glyphicon glyphicon-stats"></i> Charts</a></li>
					<li class="current"><a href="adminweightfront.php"><i class="glyphicon glyphicon-stats"></i> Qualitative Analysis</a></li>


                      <li class="submenu">
                         <a href="#">
                            <i class="glyphicon glyphicon-list"></i> Pages
                            <span class="caret pull-right"></span>
                         </a>
                         <!-- Sub menu -->
                         <ul>
                            <li><a href="http://localhost/BantuFundClean/index.php">Login</a></li>
                            <li><a href="http://localhost/BantuFundClean/index.php">Signup</a></li>
                        </ul>
                    </li>
                </ul>
             </div>
		  </div>
		  <div class="col-md-10">

		   <div class="row"> 
  			
		   		
  			<div class="content-box-large">
  			<div class="panel-heading">
					<div class="panel-title" id="drivename"> <?php echo $_SESSION['pjtname']; ?> </div>          
				</div>
  				<div class="panel-body">
            
            
  					<form action="../admin/adminweight1.php" method="post">
<div class="form-group">
<label for="id">Drive ID</label>
<input type="text" class="form-control" id="id" name="id" placeholder="<?php echo $_SESSION['pjtid']; ?> " maxlength="30" value="<?php echo $_SESSION['pjtid']; ?> " required>
	   </div>
	   
 <div class="form-group">
  <label for="adminweight">Select Appropriate Weight:</label>
  <select class="form-control" id="adminweight" name="adminweight">
    <option value="5">Very Critical</option>
    <option value="4">Critical</option>
    <option value="3">Essential</option>
    <option value="2">less essential </option>
	<!--<option value="sports">Sports</option> -->
	<option value="1">Luxary</option>
  </select>
</div>

<input type="submit" name ="submit" value="submit"/>
<form>



<?php require("connection.php"); ?>

<!--<?/php //$sqlselect ="SELECT *  FROM `drive` WHERE `Drive_Status` = 'approved' ORDER BY `weight` DESC limit 0,6";
$sqlselect ="SELECT * FROM `drive` WHERE `Drive_Status` = 'pending' ORDER BY `weight` DESC limit 0,6";

 $retval= mysqli_query($link, $sqlselect);
                      if ($retval ){
                            //echo "<p>selection2 success</p>";
                      }
                      else {
                            echo "Error: " . $sqlselect . "<br>" . mysqli_error($link);
                    } 
                         
					 //loop through associative array returned from database
                     while ($row = mysqli_fetch_assoc($retval)) {
					 ?><form>
					  <span class="img-thumbnail">
					  <input type="image" src=" </?php echo $row['Drive_Img'];?> " class="img-thumbnail" height="216" width="388" >
					  <input type="hidden" name="subweight" value="<b><h5></?php echo"{$row['subweight']}"?></h5></b>" >
					  </form>
					 <b><h5></h5>?php echo"{$row['Drive_ID']}"?></h5></b>   
					    
                     <b><h5></h5>?php echo"{$row['Drive_Target_Amount']}" ?></h5></b>
                     <b><h5></h5>?php echo"{$row['Drive_Name']}"?></h5></b>   
                     <b><h5></h5>?php echo $row['Drive_Percentage_Funded'];?></h5></b>
                     <b><h5></h5>?php echo $row['Drive_Duration'];?></h5></b>
                    
					 <b><h5></h5>?php echo $row['Full_Desc'];?></h5></b>
                     <b><h5></h5>?php echo $row['Major_Goal'];?></h5></b>
					 <b><h5>Description:</b> </h5>?php echo "{$row['Short_Desc']}";?></h5></b>
                     </span>
 <!-- img is the submit button
            
					</?php 
					 }
                      mysqli_close($link);  
                  ?>-->



 

  				</div>
  			</div>



		  </div>
		</div>
    </div>

    <footer>
         <div class="container">
         
            <div class="copy text-center">
               CyberSolutions <a href='#'>Website</a>
            </div>
            
         </div>
      </footer>

     <link href="vendors/datatables/dataTables.bootstrap.css" rel="stylesheet" media="screen">

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>

    <script src="vendors/datatables/js/jquery.dataTables.min.js"></script>

    <script src="vendors/datatables/dataTables.bootstrap.js"></script>

    <script src="js/custom.js"></script>
    <script src="js/tables.js"></script>

    <script language="javascript" type="text/javascript">
/* <![CDATA[ */
      document.write('<a id="pdf-generate" href="http://localhost/BantuFundClean/mpdf60/starter/starter.php?url=' + encodeURIComponent(location.href) +'" class="button">');
      document.write('<img src="http://your-website/images/pdf.jpg" alt="Generate PDF">');
      document.write('</a>');
/* ]]> */
</script>

  </body>
</html>
<?php
session_start();
if( !isset( $_SESSION['username'] ) )//this means the counter has been set so the and this value leads to true
  {
    $msg = "login";
      }
  else
  {
    $msg = $_SESSION['username'];

  }

?>

<!DOCTYPE html>
<html>
  <head>
    <title>BantuFund Admin </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="css/styles.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
   <?php require("conbfclean.php"); ?>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="index.php">BantuFund</a></h1>
	              </div>
	           </div>
	           <div class="col-md-5">
	              <div class="row">
	                <div class="col-lg-12">
	                  
	                </div>
	              </div>
	           </div>
	           <div class="col-md-2">
	              <div class="navbar navbar-inverse" role="banner">
	                  <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
	                    <ul class="nav navbar-nav">
	                      <li class="dropdown">
	                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Admin <b class="caret"></b></a>
	                        <ul class="dropdown-menu animated fadeInUp">
	                          
	                          <li><a href="http://localhost/BantuFundClean/logout.php">Logout</a></li>
	                        </ul>
	                      </li>
	                    </ul>
	                  </nav>
	              </div>
	           </div>
	        </div>
	     </div>
	</div>

    <div class="page-content">
    	<div class="row">
		  <div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <!-- Main menu -->
                    <li class="current"><a href="http://localhost/BantuFundClean/Admin/index.php"><i class="glyphicon glyphicon-home"></i> Home</a></li>
                    
                    
                    <li><a href="report.php"><i class="glyphicon glyphicon-list"></i> Report</a></li>
                    <li><a href="stats.php"><i class="glyphicon glyphicon-stats"></i> Charts</a></li>
                    <li><a href="adminweightfront.php"><i class="glyphicon glyphicon-stats"></i> Qualitative Analysis</a></li>

                      <li class="submenu">
                         <a href="#">
                            <i class="glyphicon glyphicon-list"></i> Pages
                            <span class="caret pull-right"></span>
                         </a>
                         <!-- Sub menu -->
                         <ul>
                            <li><a href="http://localhost/BantuFundClean/index.php">Login</a></li>
                            <li><a href="http://localhost/BantuFundClean/index.php">Signup</a></li>
                        </ul>
                    </li>
                </ul>
             </div>
		  </div>

		 

		  <div class="col-md-10">		  		
		  	<div class="content-box-large">

                <div class="container">
      <?php 
        $imgnameform = $_POST['formimgname'];
        $pjtnameform = $_POST['formpjtname'];
        $pjtidform   = $_POST['formpjtid'];
        $pjtfulldesc = $_POST['formfulldesc'];
        $pjtshotdesc = $_POST['formshotdesc'];
        $pjtgoal     = $_POST['formgoal'];

        $pjtpercentage = $_POST['formpercentage'];
        $pjtamountform = $_POST['formpjtamount'];//target
        $pjtremdays    = $_POST['daysrem']; //daysleft
              $collected = (($pjtpercentage/100) * $pjtamountform);
              $remaining = ($pjtamountform - $collected);               


             

//session_start();
        $_SESSION['pjtid'] = $pjtidform;
        $_SESSION['pjtname'] = $pjtnameform;

        $_SESSION['tgtamt']   = $pjtamountform;
        $_SESSION['remainingamt']=$remaining;
        $_SESSION['daysrem'] = $pjtremdays;
        //project duration days left
        //project target
        //amount  left

      ?>
       
        <h3> <?php echo "$pjtnameform"; ?>  </h3> 
        <div class="col-md-5"> 
                  
          <img src="<?php echo "$imgnameform"?>" class="img-thumbnail"> 

          <form name="statusform" class="form-inline" action="http://localhost/BantuFundClean/processadmin.php" method="POST">
            <div class="btn-group" data-toggle="buttons">
                  <label class="btn btn-lg btn-danger">
                    <input type="radio" name="options" id="option1" autocomplete="off" value="declined" checked=""/>
                    <span class="glyphicon glyphicon-remove-circle" >DECLINE</span>
                    
                  </label>

                   <label class="btn btn-lg btn-warning">
                    <input type="radio" name="options" id="option2" autocomplete="off" value="pending" checked="" />
                    <span class="glyphicon glyphicon-warning-sign">PENDING</span>
                    
                  </label>

                   <label class="btn btn-lg btn-success">
                    <input type="radio" name="options" id="option3" autocomplete="off" value="approved" checked="" />
                    <span class="glyphicon glyphicon-ok-circle">APPROVE</span>
                    
                  </label>
                 
               </div>
            <input type="hidden" name="fmprojid"   value=" <?php echo $pjtidform; ?> ">
            <input type="submit" >
            <p><span id="errorMessage"></span></p>
          </form>                             

        </div>

        <div class="col-md-5">
          <div class="content">
        <!-- About-->
          <div class="container" style="width: 400px">

    <h2>ABOUT</h2>  
  <h3><?php echo "$pjtnameform"; ?></h3> 
  <h4>Description</h4>
    <p><?php echo "$pjtshotdesc"; ?></p>
    <?php echo "$pjtfulldesc"; ?>
  <h4>Major Goals</h4>
    <?php echo "$pjtgoal"; ?>
  

                  
</div>        
        </div>
          
        </div>

      </div>
		  				 
		  	</div>		  			
		  </div>
		  	

		  	

		  	

		  </div>
		</div>
    </div>

    <footer>
         <div class="container">
         
            <div class="copy text-center">
              &copy; CyberSolutions <a href='#'>Website</a>
            </div>
            
         </div>
      </footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
  </body>
</html>
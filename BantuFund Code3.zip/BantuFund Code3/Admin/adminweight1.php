<?php
require("connection.php");
$w = $_POST["adminweight"];
$id =  $_POST["id"];
$sqlselect ="SELECT subweight FROM `drive` WHERE Drive_ID = '$id'";
$retval= mysqli_query($link, $sqlselect);
                      if ($retval ){
                            //echo "<p>selection2 success</p>";
                      }
                      else {
                            echo "Error: " . $sqlselect . "<br>" . mysqli_error($link);
                    } 
                         
					 //loop through associative array returned from database
                     while ($row = mysqli_fetch_assoc($retval)) {
					$sw = $row['subweight'];
					 					 
					 }
//$sw = $_POST["subweight"];
$nw = $w + $sw;
//echo $nw;
$sql = "UPDATE drive SET subweight ='$nw' WHERE Drive_ID ='$id'";
 //$sql = "UPDATE drive SET donationsofar ='$donationsofar', percent ='$percent' WHERE driveID = '$sid'";
if (mysqli_query($link, $sql)) {
 echo " drive succesfully updated";
 header('Location:index.php');

}else {

echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

                      mysqli_close($link);  

 ?>
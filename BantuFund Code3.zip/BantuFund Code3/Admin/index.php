<?php
session_start();
if( !isset( $_SESSION['username'] ) )//this means the counter has been set so the and this value leads to true
  {
    $msg = "login";
      }
  else
  {
    $msg = $_SESSION['username'];
  }

?>

<!DOCTYPE html>
<html>
  <head>
    <title>BantuFund Admin </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="css/styles.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
   <?php require("conbfclean.php"); ?>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="index.php">BantuFund</a></h1>
	              </div>
	           </div>
	           <div class="col-md-5">
	              <div class="row">
	                <div class="col-lg-12">
	                  
	                </div>
	              </div>
	           </div>
	           <div class="col-md-2">
	              <div class="navbar navbar-inverse" role="banner">
	                  <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
	                    <ul class="nav navbar-nav">
	                      <li class="dropdown">
	                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Admin <b class="caret"></b></a>
	                        <ul class="dropdown-menu animated fadeInUp">
	                          
	                          <li><a href="http://localhost/BantuFundClean/logout.php">Logout</a></li>
	                        </ul>
	                      </li>
	                    </ul>
	                  </nav>
	              </div>
	           </div>
	        </div>
	     </div>
	</div>

    <div class="page-content">
    	<div class="row">
		  <div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <!-- Main menu -->
                    <li class="current"><a href="http://localhost/BantuFundClean/Admin/index.php"><i class="glyphicon glyphicon-home"></i> Home</a></li>
                                   
                   
                    <li class="submenu">
                         <a href="#">
                            <i class="glyphicon glyphicon-list"></i> Pages
                            <span class="caret pull-right"></span>
                         </a>
                         <!-- Sub menu -->
                         <ul>
                            <li><a href="http://localhost/BantuFundClean/index.php">Login</a></li>
                            <li><a href="http://localhost/BantuFundClean/index.php">Signup</a></li>
                        </ul>
                    </li>
                </ul>
             </div>
		  </div>

		  <?php 
                  //retrieving posts from database and displaying them
                                      //retrieving from database
                   // $sqlselect ='SELECT image,drivename,driveID FROM drive';
                    $sqlselect ='SELECT * FROM drive ORDER BY Drive_ID DESC';
                      
                      //validating 
                      $retval= mysqli_query($link, $sqlselect);
                      if ($retval ){
                            //echo "<p>selection2 success</p>";
                      }
                      else {
                            echo "Error: " . $sqlselect . "<br>" . mysqli_error($link);
                    } 
                                
                  ?>
         


		  <div class="col-md-10">
		  		<?php //loop through associative array returned from database
                       while ($row = mysqli_fetch_assoc($retval)) {
                    ?>

		  	
		  		<div class="col-md-9">
		  			<div class="content-box-large">
          <form action="indexadmindetailed.php" method="POST">
            <div class="row">
              <div class="col-md-6">
                
                  <h3 name="formpjtname">         <?php echo"<p> {$row['Drive_Name']} </p>" ?></h3>  
                  <input type="hidden" name="formpjtname" value="<?php echo"{$row['Drive_Name']}" ?> " > 
                  <input type="hidden" name="formimgname" value="http://localhost/BantuFundClean/<?php echo $row['Drive_Img'];?> "  >
                  <input type="hidden" name="formpjtid"   value="<?php echo $row['Drive_ID'];?>">
                  <input type="hidden" name="formfulldesc"   value="<?php echo $row['Full_Desc'];?>">
                  <input type="hidden" name="formgoal"   value="<?php echo $row['Major_Goal'];?>">
                  <input type="hidden" name="formshotdesc"   value="<?php echo $row['Short_Desc'];?>">

                  <input type="hidden" name="formpjtamount"   value="<?php echo $row['Drive_Target_Amount'];?>">
                  <input type="hidden" name="formpercentage" value=" <?php echo $row['Drive_Percentage_Funded'];?>">

                  <!-- img is the submit button-->
                  <input type="image" src="http://localhost/BantuFundClean/<?php echo $row['Drive_Img'];?> " class="img-thumbnail" height="170" width="350" ><br>
                  <span >Status: <b name="formpjtstatus" ><?php echo"{$row['Drive_Status']}"?></b></span>


               

              </div>

              <div class="col-md-5">
              <br>
                <span>
                  <?php echo $row['Short_Desc'] ; ?>
                </span>
                   Days remaining:<b>
                      <?php 
                           
                        $now = date('Y-m-d');
                        //$days =('5days');
                          //$Date1 = '2010-09-17';
                        $days = $row['Drive_Duration'];
                        $Date2 = date('Y-m-d', strtotime($now . " + " . "$days"));
                            
                        $now = time(); // or your date as well
                        $Date3 = strtotime($Date2);
                        $datediff = $Date3 - $now;
                        echo floor($datediff / (60 * 60 * 24));

                      ?> days</b>

                <input type="hidden" name="daysrem" value=" <?php echo floor($datediff / (60 * 60 * 24));?>">

                
              </div>
              
            </div>
          </form>
		  				
		  			</div>
		  		</div>

		  		 <?php       
                      }
                       mysqli_close($link); 
                   ?> 


		  		<div class="col-md-3">
		  			
		  		</div>		  	

		  </div>
		</div>
    </div>

    <footer>
         <div class="container">
         
            <div class="copy text-center">
              &copy; CyberSolutions <a href='#'>Website</a>
            </div>
            
         </div>
      </footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
  </body>
</html>